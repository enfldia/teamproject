package project.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
