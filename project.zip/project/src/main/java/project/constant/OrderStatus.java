package project.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
