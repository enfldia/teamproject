package project.constant;

public enum Role {
    ADMIN, USER
}
